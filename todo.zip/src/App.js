import { getAllDisplayValue} from '@testing-library/react';
import { useEffect, useState} from 'react';
import './App.css';

function App() {
  let [lista, setLista] = useState([]);
  let [novoItem, setNovoItem] = useState("");

  useEffect(() => {
    setLista([]);
  }, []);

  return (
    <div className="form">
      <h1>Organize your day here!</h1>
      <div className='add'>
        <input className='text-add' placeholder="Enter you task" value={novoItem} onChange={value => setNovoItem(value.target.value)} type="text"></input>
        <button className='add-button' onClick={() => adicionarNovoItem()}>Add Item</button>
      </div>
      <ul className='todo-list'>
        {lista.map((item, index) => 
          <li key={index} className='todo-item'>
            <div>
              <input className='checkbox' type={'checkbox'}></input>
              {item}
            </div>
            <button className='delete' onClick={() => deletarItem(index)}>Remove</button>
          </li>
        )}
      </ul>
    </div>
  );

  function adicionarNovoItem() {
    setLista([...lista, novoItem]);
    setNovoItem("");
  }

  function deletarItem(index){
    let tmpArray = [...lista];
    tmpArray.splice(index, 1);
    
    setLista(tmpArray);
  }

}

export default App;
